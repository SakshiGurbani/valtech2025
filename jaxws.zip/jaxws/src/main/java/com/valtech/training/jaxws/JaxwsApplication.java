package com.valtech.training.jaxws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaxwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JaxwsApplication.class, args);
	}

}
