package com.valtech.training.jaxws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaxwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
