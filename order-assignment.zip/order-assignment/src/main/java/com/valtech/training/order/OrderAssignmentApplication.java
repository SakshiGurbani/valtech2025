package com.valtech.training.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderAssignmentApplication.class, args);
	}

}
