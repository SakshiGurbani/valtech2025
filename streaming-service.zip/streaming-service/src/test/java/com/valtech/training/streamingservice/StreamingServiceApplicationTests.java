package com.valtech.training.streamingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
